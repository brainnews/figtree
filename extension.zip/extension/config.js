// Build configuration
// Only declare if not already declared to prevent redeclaration errors
if (typeof window.IS_PRODUCTION === 'undefined') {
  window.IS_PRODUCTION = true; // Set to true for production builds
}